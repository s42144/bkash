<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Codekinda Bot</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <h1>About Codekinda Bot</h1>
    <div class="menu about">
        <h1>About Codekinda</h1>
        <p>Codekinda is a great website development channel for both beginner and advanced learners</p>
    </div>
</body>
</html>
