# telegram_mini_app1
This script will help you get your first Telegram mini app up and running. You need to watch the video on YouTube to see how it is setup. Watch it here: https://youtu.be/FOzWxKfa5tY
